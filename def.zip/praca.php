<?php
	$f = fopen("semafor","w");
	flock($f,LOCK_EX);
	
	$rawdata = file_get_contents("php://input");
	$daneJSON = json_decode($rawdata,true);
	$ok = true;
	
	if($daneJSON == null) 
	{
		$wynik = array('rez' => false, 'kod' => 1, 'bo' => 'Zły format');
		$ok = false;
	}
	
		
	if($ok)
	{
		if(isset($daneJSON['nazwa_pliku']))
		{
			if(isset($daneJSON['polecenie']))
			{
				$polecenie = intval($daneJSON['polecenie']);
				switch($polecenie)
				{
					case 1: 
						$wynik = zapiszNapis( $daneJSON ); 
					break;

					case 2: 
						$wynik = odczytajNapis( $daneJSON ); 
					break;

					case 3: 
						$wynik = podajWzory($daneJSON );
					 break;

					default: 
						$wynik = array('rez' => false, 'kod' => 3, 'bo' => 'Podane zostało złe polecenie');
				}		
			}
			else
			{
				$wynik = array('rez' => false, 'kod' => 1, 'bo' => 'Nie podano polecenia');
			}
		}
		else
		{
			$wynik = array('rez' => false, 'kod' => 1, 'bo' => 'Brak nazwy pliku');
		}
	}
	
	

	//file_put_contents("dane/wynik",$wynik);


	$wynikS = json_encode($wynik, JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE+JSON_UNESCAPED_SLASHES);
	echo $wynikS;
	
	flock($f, LOCK_UN); 
	fclose($f);


	function zapiszNapis( $daneJSON ){
		if(isset($daneJSON['nazwa_pliku'])){
			$nazwa_pliku = $daneJSON['nazwa_pliku'];
			if(isset($daneJSON['napis'])){
				if(file_exists("4073e4bf57b9e327a0ff30bc0d34d5bd/$nazwa_pliku")){
					$plik = json_decode(file_get_contents("4073e4bf57b9e327a0ff30bc0d34d5bd/$nazwa_pliku"),true);
					if($plik == null) 
						$plik = array();
				}
				else{
					$plik = array();
				}
				$plik['napis'] = $daneJSON['napis'];
				file_put_contents("4073e4bf57b9e327a0ff30bc0d34d5bd/$nazwa_pliku",
				json_encode($plik, JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE+JSON_UNESCAPED_SLASHES));			
				return array('rez' => true, 'kod' => 101, 'bo' => 'ok');
			}
			else{
				return array('rez' => false, 'kod' => 5, 'bo' => 'Brak napisu');
			}
		}
		else{
			return array('rez' => false, 'kod' => 2, 'bo' => 'Brak nazwy pliku');
		}
	}

	function odczytajNapis($daneJSON){
		$nazwa_pliku = $daneJSON['nazwa_pliku'];
		if(file_exists("4073e4bf57b9e327a0ff30bc0d34d5bd/$nazwa_pliku")){		
			$plik = json_decode(file_get_contents("4073e4bf57b9e327a0ff30bc0d34d5bd/$nazwa_pliku"),true);
			$napis = $plik['napis'] ?? ''; // Jeżeli puste/NULL nic nie wypisze
			return array('rez' => true, 'kod' => 201, 'bo' => 'ok', 'dane' => $napis);
			
		}
		else{
			return array('rez' => false, 'kod' => 5, 'bo' => 'Brak nazyw pliku');
		}
	}

	function podajWzory($daneJSON){
		$nr_wyboru = $daneJSON['nr_wyboru'] ?? 1; //Jeżeli puste/NULL przypisz domyślnie 1
		if(file_exists("danedof/wybor$nr_wyboru")){
			$plik = json_decode(file_get_contents("danedof/wybor$nr_wyboru"),true);
			if($plik == null){
				return array('rez' => false, 'kod' => 5, 'bo' => 'Zły format w pliku ');
			}
			else{		
				return array('rez' => true, 'kod' => 202, 'bo' => 'ok', 'dane' => $plik);
			}
		}
		else{
			return array('rez' => false, 'kod' => 5, 'bo' => 'Brak wyboru');
		}
	}

?>